# Project Infinity Web

A deployable Next.js web starter for Project Infinity, designed as a preventive health intelligence dashboard.

## What is included
- Next.js App Router structure
- dashboard page
- patient list page
- patient overview page
- trends page
- labs page
- alerts page
- reports page
- Infinity score page
- shared layout and styling
- mock data layer for demo content

## Run locally
```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Deploy to Vercel
### Option 1: Git-based deploy
1. Push this folder to GitHub.
2. Import the repo into Vercel.
3. Vercel will detect Next.js automatically and deploy it.

### Option 2: Vercel CLI
```bash
npm install -g vercel
vercel
```

## Notes
- `package.json` uses `next@latest`, `react@latest`, and `react-dom@latest` in line with the current Next.js App Router installation guidance. The Next.js docs currently recommend manual installation with `next@latest react@latest react-dom@latest` for App Router projects. citeturn471188search2turn471188search0
- Vercel is the native deployment platform for Next.js and supports standard `vercel` deployments from the project root. citeturn471188search1turn471188search11turn471188search15

## Structure
- `app/` route pages
- `components/` shared UI and layout
- `lib/data.ts` mock demo data
- `app/globals.css` app styling

## Next steps
- replace mock data with real API endpoints
- add authentication
- add forms for uploads and editing
- add charts with a charting library if you want richer visualizations
