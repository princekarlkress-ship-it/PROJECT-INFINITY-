export type RiskLevel = 'Low' | 'Moderate' | 'High';
export type AlertSeverity = 'Low' | 'Moderate' | 'High';

export type Patient = {
  id: string;
  name: string;
  age: number;
  sex: 'Female' | 'Male';
  score: number;
  risk: RiskLevel;
  alerts: number;
  status: string;
  lastResult: string;
  summary: string;
  actions: string[];
  issues: { title: string; detail: string; severity: 'neutral' | 'warning' | 'danger' }[];
  systems: { label: string; score: number }[];
  trends: {
    glucose: { date: string; value: number }[];
    ldl: { date: string; value: number }[];
    alt: { date: string; value: number }[];
    scoreHistory: { date: string; value: number }[];
  };
  labs: { parameter: string; result: string; range: string; status: string; trend: string; category: string }[];
  alertsData: { title: string; severity: AlertSeverity; reason: string; action: string }[];
  report: string[];
};

export const patients: Patient[] = [
  {
    id: 'PI-20491',
    name: 'Ama Mensah',
    age: 42,
    sex: 'Female',
    score: 67,
    risk: 'Moderate',
    alerts: 3,
    status: 'Follow-up due',
    lastResult: '17 Mar 2026',
    summary:
      'Worsening cardiometabolic profile with upward trends in fasting glucose, HbA1c, LDL, and blood pressure. Mild liver enzyme elevation. Renal function remains preserved.',
    actions: [
      'Repeat HbA1c and fasting glucose in 3 months',
      'Start structured blood pressure monitoring',
      'Review nutrition, exercise, and weight plan',
      'Repeat liver function test in 8–12 weeks'
    ],
    issues: [
      { title: 'LDL Increasing', detail: 'Current 3.9 mmol/L, up from 3.3', severity: 'warning' },
      { title: 'Prediabetes Risk', detail: 'HbA1c 6.1%, fasting glucose trending upward', severity: 'danger' },
      { title: 'Blood Pressure Elevated', detail: '142/90 mmHg at latest encounter', severity: 'danger' },
      { title: 'Mild Liver Elevation', detail: 'ALT mildly above reference range', severity: 'warning' }
    ],
    systems: [
      { label: 'Cardiovascular', score: 58 },
      { label: 'Metabolic', score: 61 },
      { label: 'Liver', score: 72 },
      { label: 'Renal', score: 92 },
      { label: 'Hematologic', score: 74 }
    ],
    trends: {
      glucose: [
        { date: 'Sep 2025', value: 5.8 },
        { date: 'Mar 2026', value: 6.3 }
      ],
      ldl: [
        { date: 'Sep 2025', value: 3.3 },
        { date: 'Mar 2026', value: 3.9 }
      ],
      alt: [
        { date: 'Sep 2025', value: 39 },
        { date: 'Mar 2026', value: 48 }
      ],
      scoreHistory: [
        { date: 'Sep 2025', value: 72 },
        { date: 'Mar 2026', value: 67 }
      ]
    },
    labs: [
      { parameter: 'Fasting Glucose', result: '6.3 mmol/L', range: '3.9 - 5.5', status: 'High', trend: '↑ increased', category: 'Metabolic' },
      { parameter: 'HbA1c', result: '6.1%', range: '<5.7', status: 'High', trend: '↑ increased', category: 'Metabolic' },
      { parameter: 'LDL', result: '3.9 mmol/L', range: '<3.0', status: 'High', trend: '↑ increased', category: 'Lipid' },
      { parameter: 'Triglycerides', result: '2.1 mmol/L', range: '<1.7', status: 'High', trend: '↑ increased', category: 'Lipid' },
      { parameter: 'ALT', result: '48 U/L', range: '<40', status: 'High', trend: '↑ increased', category: 'Liver' },
      { parameter: 'Hemoglobin', result: '11.4 g/dL', range: '12 - 15', status: 'Low', trend: '↓ reduced', category: 'Hematology' }
    ],
    alertsData: [
      {
        title: 'Progressive cardiometabolic risk',
        severity: 'Moderate',
        reason: 'Blood pressure, LDL, fasting glucose, and HbA1c have all worsened compared with the previous encounter.',
        action: 'Review lifestyle plan and repeat glycemic markers in 3 months'
      },
      {
        title: 'Mild liver enzyme rise',
        severity: 'Low',
        reason: 'ALT has increased between encounters while remaining only mildly above reference range.',
        action: 'Repeat liver function testing in 8–12 weeks'
      }
    ],
    report: [
      'The patient demonstrates a worsening cardiometabolic profile with elevated fasting glucose, HbA1c, LDL cholesterol, triglycerides, and blood pressure. Mild liver enzyme elevation is also noted, while renal function remains preserved.',
      'Abnormal findings include elevated LDL cholesterol, raised fasting glucose, raised HbA1c, mildly elevated ALT, and mild anemia. Trend comparison shows progression in metabolic and cardiovascular risk markers compared with the previous encounter.',
      'Recommendations include repeating glycemic markers in 3 months, structured blood pressure monitoring, lifestyle intervention, and repeat liver function assessment within 8–12 weeks.'
    ]
  },
  {
    id: 'PI-19384',
    name: 'Kofi Mensah',
    age: 50,
    sex: 'Male',
    score: 52,
    risk: 'High',
    alerts: 5,
    status: 'Review needed',
    lastResult: '15 Mar 2026',
    summary: 'Persistent hypertension and elevated LDL with declining Infinity Score.',
    actions: ['Prioritize clinician review', 'Assess medication plan'],
    issues: [{ title: 'High cardiovascular risk', detail: 'LDL and BP remain elevated', severity: 'danger' }],
    systems: [
      { label: 'Cardiovascular', score: 45 },
      { label: 'Metabolic', score: 58 },
      { label: 'Liver', score: 76 },
      { label: 'Renal', score: 85 },
      { label: 'Hematologic', score: 70 }
    ],
    trends: {
      glucose: [{ date: 'Sep 2025', value: 5.9 }, { date: 'Mar 2026', value: 6.0 }],
      ldl: [{ date: 'Sep 2025', value: 4.0 }, { date: 'Mar 2026', value: 4.4 }],
      alt: [{ date: 'Sep 2025', value: 31 }, { date: 'Mar 2026', value: 33 }],
      scoreHistory: [{ date: 'Sep 2025', value: 61 }, { date: 'Mar 2026', value: 52 }]
    },
    labs: [],
    alertsData: [],
    report: ['Cardiovascular risk remains high and requires active intervention.']
  }
];

export function getPatient(id: string): Patient {
  return patients.find((patient) => patient.id === id) ?? patients[0];
}

export const dashboardStats = [
  { label: 'Total Patients', value: '1,248' },
  { label: 'New Uploads Today', value: '32' },
  { label: 'Active Alerts', value: '18' },
  { label: 'Reports Generated', value: '24' }
];

export const recentActivity = [
  'Ama Mensah – New lab results uploaded',
  'Kofi Mensah – Alert triggered (LDL increase)',
  'Jane Doe – Report generated'
];
