import Link from 'next/link';
import { ReactNode } from 'react';
import { RiskLevel, AlertSeverity, patients, getPatient } from '@/lib/data';

export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ');
}

export function toneBadge(tone: string): string {
  if (tone === 'High' || tone === 'danger') return 'badge badge-high';
  if (tone === 'Moderate' || tone === 'warning') return 'badge badge-moderate';
  if (tone === 'Low' || tone === 'success') return 'badge badge-low';
  return 'badge badge-neutral';
}

export function scoreClass(score: number): string {
  if (score >= 85) return 'score-good';
  if (score >= 70) return 'score-fair';
  if (score >= 55) return 'score-watch';
  return 'score-bad';
}

export function PageHeader({ eyebrow, title, actions }: { eyebrow?: string; title: string; actions?: ReactNode }) {
  return (
    <header className="topbar">
      <div className="container topbar-inner">
        <div>
          {eyebrow ? <div className="eyebrow">{eyebrow}</div> : null}
          <h1 className="page-title">{title}</h1>
        </div>
        {actions ? <div className="actions">{actions}</div> : null}
      </div>
    </header>
  );
}

export function Button({ href, children, variant = 'primary' }: { href?: string; children: ReactNode; variant?: 'primary' | 'secondary' | 'ghost' }) {
  const className = cn('button', variant !== 'primary' && `button-${variant}`);
  if (href) return <Link href={href} className={className}>{children}</Link>;
  return <span className={className}>{children}</span>;
}

export function Card({ title, subtitle, children }: { title?: string; subtitle?: string; children: ReactNode }) {
  return (
    <section className="card">
      {title ? (
        <div className="card-head">
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function AppShell({ current, children }: { current: string; children: ReactNode }) {
  const nav = [
    { key: 'dashboard', label: 'Dashboard', href: '/' },
    { key: 'patients', label: 'Patients', href: '/patients' },
    { key: 'overview', label: 'Overview', href: `/patients/${patients[0].id}` },
    { key: 'trends', label: 'Trends', href: `/patients/${patients[0].id}/trends` },
    { key: 'labs', label: 'Lab Results', href: `/patients/${patients[0].id}/labs` },
    { key: 'alerts', label: 'Alerts', href: `/patients/${patients[0].id}/alerts` },
    { key: 'reports', label: 'Reports', href: `/patients/${patients[0].id}/reports` },
    { key: 'score', label: 'Infinity Score', href: `/patients/${patients[0].id}/score` }
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">∞</div>
          <div>
            <div className="brand-label">Project</div>
            <div className="brand-name">Infinity</div>
          </div>
        </div>
        <nav className="nav-list">
          {nav.map((item) => (
            <Link key={item.key} href={item.href} className={cn('nav-item', current === item.key && 'nav-item-active')}>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="sidebar-foot card compact">
          <div className="card-head">
            <h2>Today&apos;s Snapshot</h2>
          </div>
          <div className="kv-list">
            <div><span>New uploads</span><strong>18</strong></div>
            <div><span>Active alerts</span><strong>12</strong></div>
            <div><span>Reports today</span><strong>9</strong></div>
          </div>
        </div>
      </aside>
      <main className="main-content">{children}</main>
    </div>
  );
}

export function PatientTabs({ patientId, active }: { patientId: string; active: string }) {
  const tabs = [
    { key: 'overview', label: 'Overview', href: `/patients/${patientId}` },
    { key: 'trends', label: 'Trends', href: `/patients/${patientId}/trends` },
    { key: 'labs', label: 'Labs', href: `/patients/${patientId}/labs` },
    { key: 'alerts', label: 'Alerts', href: `/patients/${patientId}/alerts` },
    { key: 'reports', label: 'Reports', href: `/patients/${patientId}/reports` },
    { key: 'score', label: 'Score', href: `/patients/${patientId}/score` }
  ];
  return (
    <div className="tab-row">
      {tabs.map((tab) => (
        <Link key={tab.key} href={tab.href} className={cn('tab-pill', active === tab.key && 'tab-pill-active')}>
          {tab.label}
        </Link>
      ))}
    </div>
  );
}

export function PatientHero({ patientId }: { patientId: string }) {
  const patient = getPatient(patientId);
  return (
    <Card>
      <div className="hero-grid">
        <div>
          <div className="hero-title-row">
            <h2 className="hero-title">{patient.name}</h2>
            <span className={toneBadge(patient.risk)}>{patient.risk} Risk</span>
          </div>
          <div className="hero-meta">
            <span>{patient.age} years</span>
            <span>{patient.sex}</span>
            <span>Patient ID: {patient.id}</span>
            <span>Last update: {patient.lastResult}</span>
          </div>
          <p className="hero-copy">{patient.summary}</p>
        </div>
        <div className="score-panel">
          <div className="eyebrow">Infinity Score</div>
          <div className="score-big-wrap">
            <span className={cn('score-big', scoreClass(patient.score))}>{patient.score}</span>
            <span className="score-live">live</span>
          </div>
          <div className="progress"><div className={cn('progress-fill', scoreClass(patient.score))} style={{ width: `${patient.score}%` }} /></div>
          <div className="muted-small">Alerts: {patient.alerts} • {patient.status}</div>
        </div>
      </div>
    </Card>
  );
}
