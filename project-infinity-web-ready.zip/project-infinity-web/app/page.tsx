import Link from 'next/link';
import { AppShell, Button, Card, PageHeader, toneBadge } from '@/components/ui';
import { dashboardStats, patients, recentActivity } from '@/lib/data';

export default function HomePage() {
  return (
    <AppShell current="dashboard">
      <PageHeader
        eyebrow="Web app"
        title="Project Infinity"
        actions={<><Button variant="secondary">Upload Results</Button><Button href={`/patients/${patients[0].id}/reports`}>Generate Report</Button></>}
      />
      <div className="page-body">
        <div className="grid-4">
          {dashboardStats.map((stat) => (
            <Card key={stat.label}>
              <div className="stat">
                <div>
                  <div className="stat-label">{stat.label}</div>
                  <div className="stat-value">{stat.value}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid-main" style={{ marginTop: 24 }}>
          <Card title="High-Risk Patients" subtitle="Patients requiring attention now">
            <div className="list-rows">
              {patients.map((patient) => (
                <Link key={patient.id} href={`/patients/${patient.id}`} className="row-link">
                  <div>
                    <div className="row-title">{patient.name}</div>
                    <div className="row-sub">Score: {patient.score} • {patient.status}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span className={toneBadge(patient.risk)}>{patient.risk} Risk</span>
                    <strong style={{ color: '#dc2626' }}>{patient.alerts} Alerts</strong>
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          <Card title="Recent Activity" subtitle="Latest system events">
            <div className="list-rows">
              {recentActivity.map((item) => (
                <div key={item} className="action-item">{item}</div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
