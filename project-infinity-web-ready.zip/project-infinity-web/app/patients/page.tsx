import Link from 'next/link';
import { AppShell, Button, Card, PageHeader, toneBadge } from '@/components/ui';
import { patients } from '@/lib/data';

export default function PatientsPage() {
  return (
    <AppShell current="patients">
      <PageHeader eyebrow="Clinical records" title="Patients" actions={<><Button variant="secondary">Upload Results</Button><Button>Add Patient</Button></>} />
      <div className="page-body">
        <Card>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
            <input className="search" placeholder="Search by patient name, ID, or status" />
            <div className="filters">
              <span className="tab-pill tab-pill-active">All Patients</span>
              <span className="tab-pill">High Risk</span>
              <span className="tab-pill">Follow-up Due</span>
            </div>
          </div>
        </Card>

        <div style={{ marginTop: 24 }} className="card table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Patient</th><th>Age</th><th>Last Result</th><th>Score</th><th>Risk</th><th>Alerts</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((patient) => (
                <tr key={patient.id}>
                  <td><Link href={`/patients/${patient.id}`} className="row-title">{patient.name}</Link><div className="row-sub">{patient.id} • {patient.sex}</div></td>
                  <td>{patient.age}</td>
                  <td>{patient.lastResult}</td>
                  <td><strong>{patient.score}</strong></td>
                  <td><span className={toneBadge(patient.risk)}>{patient.risk}</span></td>
                  <td style={{ color: patient.alerts ? '#dc2626' : '#64748b', fontWeight: 700 }}>{patient.alerts}</td>
                  <td>{patient.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
