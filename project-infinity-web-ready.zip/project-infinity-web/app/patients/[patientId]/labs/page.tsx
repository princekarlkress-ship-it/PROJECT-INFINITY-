import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs, toneBadge } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientLabsPage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  return (
    <AppShell current="labs">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Lab Results" actions={<><Button href={`/patients/${patientId}`} variant="secondary">Back to Overview</Button><Button href={`/patients/${patientId}/reports`}>Generate Report</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="labs" />
        <PatientHero patientId={patientId} />
        <Card title="Filter Results" subtitle="Search and narrow the latest encounter" >
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
            <input className="search" placeholder="Search parameter, category, or result" />
            <div className="filters"><span className="tab-pill tab-pill-active">All Results</span><span className="tab-pill">Abnormal Only</span><span className="tab-pill">Worsening</span></div>
          </div>
        </Card>
        <div className="card table-wrap" style={{ marginTop: 24 }}>
          <table className="table">
            <thead><tr><th>Parameter</th><th>Result</th><th>Reference Range</th><th>Status</th><th>Trend</th><th>Category</th></tr></thead>
            <tbody>
              {patient.labs.map((row) => (
                <tr key={row.parameter}>
                  <td><strong>{row.parameter}</strong></td>
                  <td>{row.result}</td>
                  <td>{row.range}</td>
                  <td><span className={toneBadge(row.status)}>{row.status}</span></td>
                  <td>{row.trend}</td>
                  <td>{row.category}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
