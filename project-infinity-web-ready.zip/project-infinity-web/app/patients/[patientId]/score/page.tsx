import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs, scoreClass } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientScorePage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  const maxHistory = Math.max(...patient.trends.scoreHistory.map((item) => item.value));
  return (
    <AppShell current="score">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Infinity Score" actions={<><Button href={`/patients/${patientId}`} variant="secondary">Back to Overview</Button><Button href={`/patients/${patientId}/reports`}>Generate Report</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="score" />
        <PatientHero patientId={patientId} />
        <div className="grid-main" style={{ marginTop: 24 }}>
          <Card title="System Breakdown" subtitle="System-level contributors to the overall score">
            <div className="system-list">
              {patient.systems.map((system) => (
                <div className="system-row" key={system.label}>
                  <div className="system-head"><span>{system.label}</span><strong>{system.score}</strong></div>
                  <div className="progress"><div className={`progress-fill ${scoreClass(system.score)}`} style={{ width: `${system.score}%` }} /></div>
                </div>
              ))}
            </div>
          </Card>
          <Card title="Score Trend History" subtitle="Directional movement across encounters">
            <div className="chart-bars">
              {patient.trends.scoreHistory.map((point) => (
                <div className="chart-bar-col" key={point.date}>
                  <div className={`chart-value ${scoreClass(point.value)}`}>{point.value}</div>
                  <div className={`chart-bar worsening`} style={{ height: `${(point.value / maxHistory) * 180}px` }} />
                  <div className="chart-label">{point.date}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
        <div style={{ marginTop: 24 }}><Card title="Score Drivers" subtitle="Why the score changed between encounters">
          <div className="driver-grid" style={{ gridTemplateColumns: 'repeat(2, minmax(0,1fr))' }}>
            <div className="driver-card negative"><strong>LDL increase</strong><p>LDL cholesterol increased compared with the prior encounter, reducing cardiovascular system performance.</p></div>
            <div className="driver-card negative"><strong>Rising glucose markers</strong><p>Fasting glucose and HbA1c both worsened, lowering the metabolic score contribution.</p></div>
            <div className="driver-card"><strong>Stable renal function</strong><p>Creatinine remained within normal range and prevented a broader decline in the total score.</p></div>
            <div className="driver-card negative"><strong>Persistent mild anemia</strong><p>Hemoglobin remained below range and slightly worsened, lowering the hematologic score.</p></div>
          </div>
        </Card></div>
      </div>
    </AppShell>
  );
}
