import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientOverviewPage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  return (
    <AppShell current="overview">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Patient Overview" actions={<><Button href={`/patients/${patientId}/trends`} variant="secondary">View Trends</Button><Button href={`/patients/${patientId}/reports`}>Generate Report</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="overview" />
        <PatientHero patientId={patientId} />
        <div className="grid-main" style={{ marginTop: 24 }}>
          <Card title="Health Summary" subtitle="Latest clinician-facing interpretation">
            <p className="hero-copy" style={{ marginTop: 0 }}>{patient.summary}</p>
          </Card>
          <Card title="Recommended Actions" subtitle="Priority next steps">
            <div className="action-grid">
              {patient.actions.map((item) => <div key={item} className="action-item">{item}</div>)}
            </div>
          </Card>
        </div>
        <div className="grid-main" style={{ marginTop: 24 }}>
          <Card title="Key Issues" subtitle="Clinical priorities requiring attention">
            <div className="issue-grid">
              {patient.issues.map((issue) => <div key={issue.title} className={`issue-card ${issue.severity}`}><strong>{issue.title}</strong><div style={{ marginTop: 8 }}>{issue.detail}</div></div>)}
            </div>
          </Card>
          <Card title="Score Breakdown" subtitle="System performance view">
            <div className="system-list">
              {patient.systems.map((system) => (
                <div key={system.label} className="system-row">
                  <div className="system-head"><span>{system.label}</span><strong>{system.score}</strong></div>
                  <div className="progress"><div className={`progress-fill ${system.score >= 85 ? 'score-good' : system.score >= 70 ? 'score-fair' : system.score >= 55 ? 'score-watch' : 'score-bad'}`} style={{ width: `${system.score}%` }} /></div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
