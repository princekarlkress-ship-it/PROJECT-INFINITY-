import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs, toneBadge } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientReportsPage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  return (
    <AppShell current="reports">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Reports" actions={<><Button href={`/patients/${patientId}`} variant="secondary">Back to Overview</Button><Button>Generate New Report</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="reports" />
        <PatientHero patientId={patientId} />
        <div className="grid-main" style={{ marginTop: 24 }}>
          <Card title="Report Preview" subtitle={`Current draft for ${patient.name}`}>
            <div style={{ marginBottom: 12 }}><span className={toneBadge('Moderate')}>Draft</span></div>
            <div className="card compact report-body">
              <div style={{ textAlign: 'center', marginBottom: 18 }}>
                <strong>Wellness Screening Report & Recommendations</strong>
                <div className="eyebrow">{patient.name} • {patient.lastResult}</div>
              </div>
              {patient.report.map((paragraph, index) => <p key={index}>{paragraph}</p>)}
            </div>
            <div className="actions" style={{ marginTop: 16 }}>
              <Button variant="secondary">Edit</Button>
              <Button>Finalize Report</Button>
              <Button variant="ghost">Download PDF</Button>
            </div>
          </Card>
          <Card title="Report History" subtitle="Versions and prior communication states">
            <div className="list-rows">
              {['v3 • Draft • 17 Mar 2026', 'v2 • Final • 17 Mar 2026', 'v1 • Sent • 10 Sep 2025'].map((item) => (
                <div key={item} className="action-item">{item}</div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
