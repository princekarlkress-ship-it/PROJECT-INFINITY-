import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs, toneBadge } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientAlertsPage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  return (
    <AppShell current="alerts">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Alerts" actions={<><Button href={`/patients/${patientId}`} variant="secondary">Back to Overview</Button><Button>Open High-Risk Queue</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="alerts" />
        <PatientHero patientId={patientId} />
        <div className="grid-2" style={{ marginTop: 24 }}>
          {patient.alertsData.map((alert) => (
            <Card key={alert.title} title={alert.title} subtitle="Clinical action queue">
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 12 }}>
                <span className={toneBadge(alert.severity)}>{alert.severity}</span>
                <span className="badge badge-neutral">Open</span>
              </div>
              <p className="hero-copy" style={{ marginTop: 0 }}>{alert.reason}</p>
              <p><strong>Suggested action:</strong> {alert.action}</p>
              <div className="actions" style={{ marginTop: 16 }}>
                <Button variant="secondary">Review</Button>
                <Button variant="ghost">Add Note</Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
