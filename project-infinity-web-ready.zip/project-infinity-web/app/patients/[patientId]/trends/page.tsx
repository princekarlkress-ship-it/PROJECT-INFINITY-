import { AppShell, Button, Card, PageHeader, PatientHero, PatientTabs, toneBadge } from '@/components/ui';
import { getPatient } from '@/lib/data';

export default async function PatientTrendsPage({ params }: { params: Promise<{ patientId: string }> }) {
  const { patientId } = await params;
  const patient = getPatient(patientId);
  const systems = [
    { title: 'Cardiovascular', summary: 'LDL and blood pressure are trending upward, increasing overall cardiovascular risk.', state: 'worsening' },
    { title: 'Metabolic', summary: 'Fasting glucose and HbA1c are moving upward toward a stronger prediabetes profile.', state: 'worsening' },
    { title: 'Liver', summary: 'ALT has risen mildly across encounters and requires monitoring.', state: 'worsening' },
    { title: 'Renal', summary: 'Creatinine remains within normal range with no concerning directional change.', state: 'stable' }
  ];
  return (
    <AppShell current="trends">
      <PageHeader eyebrow={`Patients / ${patientId}`} title="Trends" actions={<><Button href={`/patients/${patientId}`} variant="secondary">Back to Overview</Button><Button href={`/patients/${patientId}/reports`}>Generate Report</Button></>} />
      <div className="page-body">
        <PatientTabs patientId={patientId} active="trends" />
        <PatientHero patientId={patientId} />
        <div className="grid-4" style={{ marginTop: 24 }}>
          {systems.map((item) => <Card key={item.title}><div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><strong>{item.title}</strong><p className="hero-copy" style={{ marginTop: 10 }}>{item.summary}</p></div><span className={toneBadge(item.state === 'worsening' ? 'High' : 'Neutral')}>{item.state}</span></div></Card>)}
        </div>
        <div className="grid-2" style={{ marginTop: 24 }}>
          {[{ label: 'Fasting Glucose', data: patient.trends.glucose, state: 'worsening' }, { label: 'LDL Cholesterol', data: patient.trends.ldl, state: 'worsening' }].map((chart) => {
            const max = Math.max(...chart.data.map((d) => d.value));
            return (
              <Card key={chart.label} title={chart.label} subtitle="Trend view">
                <div className="chart-bars">
                  {chart.data.map((point) => (
                    <div className="chart-bar-col" key={point.date}>
                      <div className="chart-value">{point.value}</div>
                      <div className={`chart-bar ${chart.state}`} style={{ height: `${(point.value / max) * 180}px` }} />
                      <div className="chart-label">{point.date}</div>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
